var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/plus-ai.ts
var plus_ai_exports = {};
__export(plus_ai_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(plus_ai_exports);

// node_modules/@netlify/runtime-utils/dist/main.js
var getString = (input) => typeof input === "string" ? input : JSON.stringify(input);
var base64Decode = globalThis.Buffer ? (input) => Buffer.from(input, "base64").toString() : (input) => atob(input);
var base64Encode = globalThis.Buffer ? (input) => Buffer.from(getString(input)).toString("base64") : (input) => btoa(getString(input));
var getEnvironment = () => {
  const { Deno, Netlify, process: process2 } = globalThis;
  return Netlify?.env ?? Deno?.env ?? {
    delete: (key) => delete process2?.env[key],
    get: (key) => process2?.env[key],
    has: (key) => Boolean(process2?.env[key]),
    set: (key, value) => {
      if (process2?.env) {
        process2.env[key] = value;
      }
    },
    toObject: () => process2?.env ?? {}
  };
};

// node_modules/@netlify/otel/dist/main.js
var GET_TRACER = "__netlify__getTracer";
var getTracer = (name, version) => {
  return globalThis[GET_TRACER]?.(name, version);
};
function withActiveSpan(tracer, name, optionsOrFn, contextOrFn, fn) {
  const func = typeof contextOrFn === "function" ? contextOrFn : typeof optionsOrFn === "function" ? optionsOrFn : fn;
  if (!func) {
    throw new Error("function to execute with active span is missing");
  }
  if (!tracer) {
    return func();
  }
  return tracer.withActiveSpan(name, optionsOrFn, contextOrFn, func);
}

// node_modules/@netlify/blobs/dist/chunk-YAGWSQMB.js
var getEnvironmentContext = () => {
  const context = globalThis.netlifyBlobsContext || getEnvironment().get("NETLIFY_BLOBS_CONTEXT");
  if (typeof context !== "string" || !context) {
    return {};
  }
  const data = base64Decode(context);
  try {
    return JSON.parse(data);
  } catch {
  }
  return {};
};
var MissingBlobsEnvironmentError = class extends Error {
  constructor(requiredProperties) {
    super(
      `The environment has not been configured to use Netlify Blobs. To use it manually, supply the following properties when creating a store: ${requiredProperties.join(
        ", "
      )}`
    );
    this.name = "MissingBlobsEnvironmentError";
  }
};
var BASE64_PREFIX = "b64;";
var METADATA_HEADER_INTERNAL = "x-amz-meta-user";
var METADATA_HEADER_EXTERNAL = "netlify-blobs-metadata";
var METADATA_MAX_SIZE = 2 * 1024;
var encodeMetadata = (metadata) => {
  if (!metadata) {
    return null;
  }
  const encodedObject = base64Encode(JSON.stringify(metadata));
  const payload = `b64;${encodedObject}`;
  if (METADATA_HEADER_EXTERNAL.length + payload.length > METADATA_MAX_SIZE) {
    throw new Error("Metadata object exceeds the maximum size");
  }
  return payload;
};
var decodeMetadata = (header) => {
  if (!header?.startsWith(BASE64_PREFIX)) {
    return {};
  }
  const encodedData = header.slice(BASE64_PREFIX.length);
  const decodedData = base64Decode(encodedData);
  const metadata = JSON.parse(decodedData);
  return metadata;
};
var getMetadataFromResponse = (response) => {
  if (!response.headers) {
    return {};
  }
  const value = response.headers.get(METADATA_HEADER_EXTERNAL) || response.headers.get(METADATA_HEADER_INTERNAL);
  try {
    return decodeMetadata(value);
  } catch {
    throw new Error(
      "An internal error occurred while trying to retrieve the metadata for an entry. Please try updating to the latest version of the Netlify Blobs client."
    );
  }
};
var NF_ERROR = "x-nf-error";
var NF_REQUEST_ID = "x-nf-request-id";
var BlobsInternalError = class extends Error {
  constructor(res) {
    let details = res.headers.get(NF_ERROR) || `${res.status} status code`;
    if (res.headers.has(NF_REQUEST_ID)) {
      details += `, ID: ${res.headers.get(NF_REQUEST_ID)}`;
    }
    super(`Netlify Blobs has generated an internal error (${details})`);
    this.name = "BlobsInternalError";
  }
};
var collectIterator = async (iterator) => {
  const result = [];
  for await (const item of iterator) {
    result.push(item);
  }
  return result;
};
function withSpan(span, name, fn) {
  if (span)
    return fn(span);
  return withActiveSpan(getTracer(), name, (span2) => {
    return fn(span2);
  });
}
var BlobsConsistencyError = class extends Error {
  constructor() {
    super(
      `Netlify Blobs has failed to perform a read using strong consistency because the environment has not been configured with a 'uncachedEdgeURL' property`
    );
    this.name = "BlobsConsistencyError";
  }
};
var regions = {
  "us-east-1": true,
  "us-east-2": true,
  "eu-central-1": true,
  "ap-southeast-1": true,
  "ap-southeast-2": true
};
var isValidRegion = (input) => Object.keys(regions).includes(input);
var InvalidBlobsRegionError = class extends Error {
  constructor(region) {
    super(
      `${region} is not a supported Netlify Blobs region. Supported values are: ${Object.keys(regions).join(", ")}.`
    );
    this.name = "InvalidBlobsRegionError";
  }
};
var DEFAULT_RETRY_DELAY = getEnvironment().get("NODE_ENV") === "test" ? 1 : 5e3;
var MIN_RETRY_DELAY = 1e3;
var MAX_RETRY = 5;
var RATE_LIMIT_HEADER = "X-RateLimit-Reset";
var fetchAndRetry = async (fetch2, url, options, attemptsLeft = MAX_RETRY) => {
  try {
    const res = await fetch2(url, options);
    if (attemptsLeft > 0 && (res.status === 429 || res.status >= 500)) {
      const delay = getDelay(res.headers.get(RATE_LIMIT_HEADER));
      await sleep(delay);
      return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
    }
    return res;
  } catch (error) {
    if (attemptsLeft === 0) {
      throw error;
    }
    const delay = getDelay();
    await sleep(delay);
    return fetchAndRetry(fetch2, url, options, attemptsLeft - 1);
  }
};
var getDelay = (rateLimitReset) => {
  if (!rateLimitReset) {
    return DEFAULT_RETRY_DELAY;
  }
  return Math.max(Number(rateLimitReset) * 1e3 - Date.now(), MIN_RETRY_DELAY);
};
var sleep = (ms) => new Promise((resolve) => {
  setTimeout(resolve, ms);
});
var SIGNED_URL_ACCEPT_HEADER = "application/json;type=signed-url";
var Client = class {
  constructor({ apiURL, consistency, edgeURL, fetch: fetch2, region, siteID, token, uncachedEdgeURL }) {
    this.apiURL = apiURL;
    this.consistency = consistency ?? "eventual";
    this.edgeURL = edgeURL;
    this.fetch = fetch2 ?? globalThis.fetch;
    this.region = region;
    this.siteID = siteID;
    this.token = token;
    this.uncachedEdgeURL = uncachedEdgeURL;
    if (!this.fetch) {
      throw new Error(
        "Netlify Blobs could not find a `fetch` client in the global scope. You can either update your runtime to a version that includes `fetch` (like Node.js 18.0.0 or above), or you can supply your own implementation using the `fetch` property."
      );
    }
  }
  async getFinalRequest({
    consistency: opConsistency,
    key,
    metadata,
    method,
    parameters = {},
    storeName
  }) {
    const encodedMetadata = encodeMetadata(metadata);
    const consistency = opConsistency ?? this.consistency;
    let urlPath = `/${this.siteID}`;
    if (storeName) {
      urlPath += `/${storeName}`;
    }
    if (key) {
      urlPath += `/${key}`;
    }
    if (this.edgeURL) {
      if (consistency === "strong" && !this.uncachedEdgeURL) {
        throw new BlobsConsistencyError();
      }
      const headers = {
        authorization: `Bearer ${this.token}`
      };
      if (encodedMetadata) {
        headers[METADATA_HEADER_INTERNAL] = encodedMetadata;
      }
      if (this.region) {
        urlPath = `/region:${this.region}${urlPath}`;
      }
      const url2 = new URL(urlPath, consistency === "strong" ? this.uncachedEdgeURL : this.edgeURL);
      for (const key2 in parameters) {
        url2.searchParams.set(key2, parameters[key2]);
      }
      return {
        headers,
        url: url2.toString()
      };
    }
    const apiHeaders = { authorization: `Bearer ${this.token}` };
    const url = new URL(`/api/v1/blobs${urlPath}`, this.apiURL ?? "https://api.netlify.com");
    for (const key2 in parameters) {
      url.searchParams.set(key2, parameters[key2]);
    }
    if (this.region) {
      url.searchParams.set("region", this.region);
    }
    if (storeName === void 0 || key === void 0) {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    if (encodedMetadata) {
      apiHeaders[METADATA_HEADER_EXTERNAL] = encodedMetadata;
    }
    if (method === "head" || method === "delete") {
      return {
        headers: apiHeaders,
        url: url.toString()
      };
    }
    const res = await this.fetch(url.toString(), {
      headers: { ...apiHeaders, accept: SIGNED_URL_ACCEPT_HEADER },
      method
    });
    if (res.status !== 200) {
      throw new BlobsInternalError(res);
    }
    const { url: signedURL } = await res.json();
    const userHeaders = encodedMetadata ? { [METADATA_HEADER_INTERNAL]: encodedMetadata } : void 0;
    return {
      headers: userHeaders,
      url: signedURL
    };
  }
  async makeRequest({
    body,
    conditions = {},
    consistency,
    headers: extraHeaders,
    key,
    metadata,
    method,
    parameters,
    storeName
  }) {
    const { headers: baseHeaders = {}, url } = await this.getFinalRequest({
      consistency,
      key,
      metadata,
      method,
      parameters,
      storeName
    });
    const headers = {
      ...baseHeaders,
      ...extraHeaders
    };
    if (method === "put") {
      headers["cache-control"] = "max-age=0, stale-while-revalidate=60";
    }
    if ("onlyIfMatch" in conditions && conditions.onlyIfMatch) {
      headers["if-match"] = conditions.onlyIfMatch;
    } else if ("onlyIfNew" in conditions && conditions.onlyIfNew) {
      headers["if-none-match"] = "*";
    }
    const options = {
      body,
      headers,
      method
    };
    if (body instanceof ReadableStream) {
      options.duplex = "half";
    }
    return fetchAndRetry(this.fetch, url, options);
  }
};
var getClientOptions = (options, contextOverride) => {
  const context = contextOverride ?? getEnvironmentContext();
  const siteID = context.siteID ?? options.siteID;
  const token = context.token ?? options.token;
  if (!siteID || !token) {
    throw new MissingBlobsEnvironmentError(["siteID", "token"]);
  }
  if (options.region !== void 0 && !isValidRegion(options.region)) {
    throw new InvalidBlobsRegionError(options.region);
  }
  const clientOptions = {
    apiURL: context.apiURL ?? options.apiURL,
    consistency: options.consistency,
    edgeURL: context.edgeURL ?? options.edgeURL,
    fetch: options.fetch,
    region: options.region,
    siteID,
    token,
    uncachedEdgeURL: context.uncachedEdgeURL ?? options.uncachedEdgeURL
  };
  return clientOptions;
};

// node_modules/@netlify/blobs/dist/main.js
var DEPLOY_STORE_PREFIX = "deploy:";
var LEGACY_STORE_INTERNAL_PREFIX = "netlify-internal/legacy-namespace/";
var SITE_STORE_PREFIX = "site:";
var STATUS_OK = 200;
var STATUS_PRE_CONDITION_FAILED = 412;
var Store = class _Store {
  constructor(options) {
    this.client = options.client;
    if ("deployID" in options) {
      _Store.validateDeployID(options.deployID);
      let name = DEPLOY_STORE_PREFIX + options.deployID;
      if (options.name) {
        name += `:${options.name}`;
      }
      this.name = name;
    } else if (options.name.startsWith(LEGACY_STORE_INTERNAL_PREFIX)) {
      const storeName = options.name.slice(LEGACY_STORE_INTERNAL_PREFIX.length);
      _Store.validateStoreName(storeName);
      this.name = storeName;
    } else {
      _Store.validateStoreName(options.name);
      this.name = SITE_STORE_PREFIX + options.name;
    }
  }
  async delete(key) {
    const res = await this.client.makeRequest({ key, method: "delete", storeName: this.name });
    if (![200, 204, 404].includes(res.status)) {
      throw new BlobsInternalError(res);
    }
  }
  async deleteAll() {
    let totalDeletedBlobs = 0;
    let hasMore = true;
    while (hasMore) {
      const res = await this.client.makeRequest({ method: "delete", storeName: this.name });
      if (res.status !== 200) {
        throw new BlobsInternalError(res);
      }
      const data = await res.json();
      if (typeof data.blobs_deleted !== "number") {
        throw new BlobsInternalError(res);
      }
      totalDeletedBlobs += data.blobs_deleted;
      hasMore = typeof data.has_more === "boolean" && data.has_more;
    }
    return {
      deletedBlobs: totalDeletedBlobs
    };
  }
  async get(key, options) {
    return withSpan(options?.span, "blobs.get", async (span) => {
      const { consistency, type } = options ?? {};
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.type": type,
        "blobs.method": "GET",
        "blobs.consistency": consistency
      });
      const res = await this.client.makeRequest({
        consistency,
        key,
        method: "get",
        storeName: this.name
      });
      span?.setAttributes({
        "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        return null;
      }
      if (res.status !== 200) {
        throw new BlobsInternalError(res);
      }
      if (type === void 0 || type === "text") {
        return res.text();
      }
      if (type === "arrayBuffer") {
        return res.arrayBuffer();
      }
      if (type === "blob") {
        return res.blob();
      }
      if (type === "json") {
        return res.json();
      }
      if (type === "stream") {
        return res.body;
      }
      throw new BlobsInternalError(res);
    });
  }
  async getMetadata(key, options = {}) {
    return withSpan(options?.span, "blobs.getMetadata", async (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "HEAD",
        "blobs.consistency": options.consistency
      });
      const res = await this.client.makeRequest({
        consistency: options.consistency,
        key,
        method: "head",
        storeName: this.name
      });
      span?.setAttributes({
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        return null;
      }
      if (res.status !== 200 && res.status !== 304) {
        throw new BlobsInternalError(res);
      }
      const etag = res?.headers.get("etag") ?? void 0;
      const metadata = getMetadataFromResponse(res);
      const result = {
        etag,
        metadata
      };
      return result;
    });
  }
  async getWithMetadata(key, options) {
    return withSpan(options?.span, "blobs.getWithMetadata", async (span) => {
      const { consistency, etag: requestETag, type } = options ?? {};
      const headers = requestETag ? { "if-none-match": requestETag } : void 0;
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "GET",
        "blobs.consistency": options?.consistency,
        "blobs.type": type,
        "blobs.request.etag": requestETag
      });
      const res = await this.client.makeRequest({
        consistency,
        headers,
        key,
        method: "get",
        storeName: this.name
      });
      const responseETag = res?.headers.get("etag") ?? void 0;
      span?.setAttributes({
        "blobs.response.body.size": res.headers.get("content-length") ?? void 0,
        "blobs.response.etag": responseETag,
        "blobs.response.status": res.status
      });
      if (res.status === 404) {
        return null;
      }
      if (res.status !== 200 && res.status !== 304) {
        throw new BlobsInternalError(res);
      }
      const metadata = getMetadataFromResponse(res);
      const result = {
        etag: responseETag,
        metadata
      };
      if (res.status === 304 && requestETag) {
        return { data: null, ...result };
      }
      if (type === void 0 || type === "text") {
        return { data: await res.text(), ...result };
      }
      if (type === "arrayBuffer") {
        return { data: await res.arrayBuffer(), ...result };
      }
      if (type === "blob") {
        return { data: await res.blob(), ...result };
      }
      if (type === "json") {
        return { data: await res.json(), ...result };
      }
      if (type === "stream") {
        return { data: res.body, ...result };
      }
      throw new Error(`Invalid 'type' property: ${type}. Expected: arrayBuffer, blob, json, stream, or text.`);
    });
  }
  list(options = {}) {
    return withSpan(options.span, "blobs.list", (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.method": "GET",
        "blobs.list.paginate": options.paginate ?? false
      });
      const iterator = this.getListIterator(options);
      if (options.paginate) {
        return iterator;
      }
      return collectIterator(iterator).then(
        (items) => items.reduce(
          (acc, item) => ({
            blobs: [...acc.blobs, ...item.blobs],
            directories: [...acc.directories, ...item.directories]
          }),
          { blobs: [], directories: [] }
        )
      );
    });
  }
  async set(key, data, options = {}) {
    return withSpan(options.span, "blobs.set", async (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "PUT",
        "blobs.data.size": typeof data == "string" ? data.length : data instanceof Blob ? data.size : data.byteLength,
        "blobs.data.type": typeof data == "string" ? "string" : data instanceof Blob ? "blob" : "arrayBuffer",
        "blobs.atomic": Boolean(options.onlyIfMatch ?? options.onlyIfNew)
      });
      _Store.validateKey(key);
      const conditions = _Store.getConditions(options);
      const res = await this.client.makeRequest({
        conditions,
        body: data,
        key,
        metadata: options.metadata,
        method: "put",
        storeName: this.name
      });
      const etag = res.headers.get("etag") ?? "";
      span?.setAttributes({
        "blobs.response.etag": etag,
        "blobs.response.status": res.status
      });
      if (conditions) {
        return res.status === STATUS_PRE_CONDITION_FAILED ? { modified: false } : { etag, modified: true };
      }
      if (res.status === STATUS_OK) {
        return {
          etag,
          modified: true
        };
      }
      throw new BlobsInternalError(res);
    });
  }
  async setJSON(key, data, options = {}) {
    return withSpan(options.span, "blobs.setJSON", async (span) => {
      span?.setAttributes({
        "blobs.store": this.name,
        "blobs.key": key,
        "blobs.method": "PUT",
        "blobs.data.type": "json"
      });
      _Store.validateKey(key);
      const conditions = _Store.getConditions(options);
      const payload = JSON.stringify(data);
      const headers = {
        "content-type": "application/json"
      };
      const res = await this.client.makeRequest({
        ...conditions,
        body: payload,
        headers,
        key,
        metadata: options.metadata,
        method: "put",
        storeName: this.name
      });
      const etag = res.headers.get("etag") ?? "";
      span?.setAttributes({
        "blobs.response.etag": etag,
        "blobs.response.status": res.status
      });
      if (conditions) {
        return res.status === STATUS_PRE_CONDITION_FAILED ? { modified: false } : { etag, modified: true };
      }
      if (res.status === STATUS_OK) {
        return {
          etag,
          modified: true
        };
      }
      throw new BlobsInternalError(res);
    });
  }
  static formatListResultBlob(result) {
    if (!result.key) {
      return null;
    }
    return {
      etag: result.etag,
      key: result.key
    };
  }
  static getConditions(options) {
    if ("onlyIfMatch" in options && "onlyIfNew" in options) {
      throw new Error(
        `The 'onlyIfMatch' and 'onlyIfNew' options are mutually exclusive. Using 'onlyIfMatch' will make the write succeed only if there is an entry for the key with the given content, while 'onlyIfNew' will make the write succeed only if there is no entry for the key.`
      );
    }
    if ("onlyIfMatch" in options && options.onlyIfMatch) {
      if (typeof options.onlyIfMatch !== "string") {
        throw new Error(`The 'onlyIfMatch' property expects a string representing an ETag.`);
      }
      return {
        onlyIfMatch: options.onlyIfMatch
      };
    }
    if ("onlyIfNew" in options && options.onlyIfNew) {
      if (typeof options.onlyIfNew !== "boolean") {
        throw new Error(
          `The 'onlyIfNew' property expects a boolean indicating whether the write should fail if an entry for the key already exists.`
        );
      }
      return {
        onlyIfNew: true
      };
    }
  }
  static validateKey(key) {
    if (key === "") {
      throw new Error("Blob key must not be empty.");
    }
    if (key.startsWith("/") || key.startsWith("%2F")) {
      throw new Error("Blob key must not start with forward slash (/).");
    }
    if (new TextEncoder().encode(key).length > 600) {
      throw new Error(
        "Blob key must be a sequence of Unicode characters whose UTF-8 encoding is at most 600 bytes long."
      );
    }
  }
  static validateDeployID(deployID) {
    if (!/^\w{1,24}$/.test(deployID)) {
      throw new Error(`'${deployID}' is not a valid Netlify deploy ID.`);
    }
  }
  static validateStoreName(name) {
    if (name.includes("/") || name.includes("%2F")) {
      throw new Error("Store name must not contain forward slashes (/).");
    }
    if (new TextEncoder().encode(name).length > 64) {
      throw new Error(
        "Store name must be a sequence of Unicode characters whose UTF-8 encoding is at most 64 bytes long."
      );
    }
  }
  getListIterator(options) {
    const { client, name: storeName } = this;
    const parameters = {};
    if (options?.prefix) {
      parameters.prefix = options.prefix;
    }
    if (options?.directories) {
      parameters.directories = "true";
    }
    return {
      [Symbol.asyncIterator]() {
        let currentCursor = null;
        let done = false;
        return {
          async next() {
            return withSpan(options?.span, "blobs.list.next", async (span) => {
              span?.setAttributes({
                "blobs.store": storeName,
                "blobs.method": "GET",
                "blobs.list.paginate": options?.paginate ?? false,
                "blobs.list.done": done,
                "blobs.list.cursor": currentCursor ?? void 0
              });
              if (done) {
                return { done: true, value: void 0 };
              }
              const nextParameters = { ...parameters };
              if (currentCursor !== null) {
                nextParameters.cursor = currentCursor;
              }
              const res = await client.makeRequest({
                method: "get",
                parameters: nextParameters,
                storeName
              });
              span?.setAttributes({
                "blobs.response.status": res.status
              });
              let blobs = [];
              let directories = [];
              if (![200, 204, 404].includes(res.status)) {
                throw new BlobsInternalError(res);
              }
              if (res.status === 404) {
                done = true;
              } else {
                const page = await res.json();
                if (page.next_cursor) {
                  currentCursor = page.next_cursor;
                } else {
                  done = true;
                }
                blobs = (page.blobs ?? []).map(_Store.formatListResultBlob).filter(Boolean);
                directories = page.directories ?? [];
              }
              return {
                done: false,
                value: {
                  blobs,
                  directories
                }
              };
            });
          }
        };
      }
    };
  }
};
var getStore = (input, options) => {
  if (typeof input === "string") {
    const contextOverride = options?.siteID && options?.token ? { siteID: options?.siteID, token: options?.token } : void 0;
    const clientOptions = getClientOptions(options ?? {}, contextOverride);
    const client = new Client(clientOptions);
    return new Store({ client, name: input });
  }
  if (typeof input?.name === "string") {
    const { name } = input;
    const contextOverride = input?.siteID && input?.token ? { siteID: input?.siteID, token: input?.token } : void 0;
    const clientOptions = getClientOptions(input, contextOverride);
    if (!name) {
      throw new MissingBlobsEnvironmentError(["name"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, name });
  }
  if (typeof input?.deployID === "string") {
    const clientOptions = getClientOptions(input);
    const { deployID } = input;
    if (!deployID) {
      throw new MissingBlobsEnvironmentError(["deployID"]);
    }
    const client = new Client(clientOptions);
    return new Store({ client, deployID });
  }
  throw new Error(
    "The `getStore` method requires the name of the store as a string or as the `name` property of an options object"
  );
};

// netlify/functions/_shared/plus.ts
var import_node_crypto = require("crypto");
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type, x-identity-token, x-plus-token",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Cache-Control": "no-store"
};
function json(data, status = 200) {
  return {
    statusCode: status,
    headers: { ...corsHeaders, "Content-Type": "application/json; charset=utf-8" },
    body: JSON.stringify(data)
  };
}
function normalizeDeviceId(value) {
  return String(value || "").trim().replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 96);
}
function hashValue(value) {
  return (0, import_node_crypto.createHash)("sha256").update(value).digest("hex");
}
function tokenSecret() {
  const secret = process.env.PLUS_TOKEN_SECRET;
  if (!secret || secret.length < 24)
    throw new Error("PLUS_TOKEN_SECRET is not configured");
  return secret;
}
function verifyPlusToken(token, deviceId) {
  const [body, supplied] = String(token || "").split(".");
  if (!body || !supplied)
    throw new Error("Invalid access token");
  const expected = (0, import_node_crypto.createHmac)("sha256", tokenSecret()).update(body).digest("base64url");
  const a = Buffer.from(supplied);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !(0, import_node_crypto.timingSafeEqual)(a, b))
    throw new Error("Invalid access token");
  const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  if (payload.tier !== "plus" || !payload.exp || payload.exp <= Date.now())
    throw new Error("Access expired");
  if (deviceId && payload.sub !== hashValue(normalizeDeviceId(deviceId)))
    throw new Error("Access belongs to another device");
  return payload;
}
function bearerTokenFromHeaders(headers) {
  return (headers.authorization || headers.Authorization || headers["x-plus-token"] || headers["X-Plus-Token"] || "").replace(/^Bearer\s+/i, "").trim();
}

// netlify/functions/plus-ai.ts
function compactContext(value) {
  const text = JSON.stringify(value || {});
  return text.slice(0, 6e3);
}
function fallbackRecommendation(feature, body, language) {
  const en = language === "English";
  if (feature === "nutrition_plan") {
    const goal = String(body.answers?.goal || "").replace(/_/g, " ");
    const style = String(body.answers?.style || "simple");
    const avoid = String(body.answers?.restriction || body.answers?.avoid || "").trim();
    return {
      title: en ? `7-day ${style} Plus menu` : `Men\xFA Plus ${style} de 7 d\xEDas`,
      weeklyPlan: en ? `Monday: breakfast yogurt with oats and fruit; lunch chicken rice bowl with vegetables; dinner omelette with salad; snack fruit or yogurt.
Tuesday: breakfast eggs and toast; lunch lentils with vegetables; dinner tuna potato salad; snack nuts.
Wednesday: breakfast smoothie with oats; lunch chicken wrap; dinner tofu or eggs with rice; snack fruit.
Thursday: breakfast yogurt bowl; lunch chickpea salad; dinner turkey or tofu with vegetables; snack yogurt.
Friday: breakfast eggs and fruit; lunch pasta with tuna or lentils; dinner protein salad; snack nuts.
Saturday: breakfast toast with eggs; lunch rice bowl; dinner easy homemade pizza with protein; snack fruit.
Sunday: breakfast yogurt and oats; lunch roast tray or legumes; dinner light eggs and vegetables; snack yogurt.` : `Lunes: desayuno yogur con avena y fruta; comida arroz con pollo y verduras; cena tortilla con ensalada; snack fruta o yogur.
Martes: desayuno huevos y tostada; comida lentejas con verduras; cena ensalada de patata y at\xFAn; snack frutos secos.
Mi\xE9rcoles: desayuno batido con avena; comida wrap de pollo; cena tofu o huevos con arroz; snack fruta.
Jueves: desayuno bol de yogur; comida ensalada de garbanzos; cena pavo o tofu con verduras; snack yogur.
Viernes: desayuno huevos y fruta; comida pasta con at\xFAn o lentejas; cena ensalada proteica; snack frutos secos.
S\xE1bado: desayuno tostada con huevos; comida bol de arroz; cena pizza casera f\xE1cil con prote\xEDna; snack fruta.
Domingo: desayuno yogur y avena; comida bandeja al horno o legumbres; cena ligera con huevos y verduras; snack yogur.`,
      shopping: en ? "Protein: chicken, eggs, yogurt, tuna or legumes. Carbs: rice, potatoes, bread or oats. Extras: frozen vegetables, fruit, olive oil." : "Prote\xEDna: pollo, huevos, yogur, at\xFAn o legumbres. Carbohidrato: arroz, patatas, pan o avena. Extra: verduras congeladas, fruta, aceite de oliva.",
      prep: en ? "Cook one carb base, prepare two proteins and keep emergency options ready: yogurt, eggs, tuna or legumes." : "Cocina una base de carbohidrato, deja dos prote\xEDnas listas y ten emergencias: yogur, huevos, at\xFAn o legumbres.",
      rules: en ? `Each main meal: palm of protein, fist of carbs, vegetables. It supports ${goal || "your goal"} with normal food. ${avoid ? `Avoid or replace: ${avoid}.` : ""}` : `Cada comida principal: palma de prote\xEDna, pu\xF1o de carbohidrato y verduras. Encaja con ${goal || "tu objetivo"} usando comida normal. ${avoid ? `Evita o sustituye: ${avoid}.` : ""}`,
      fallback: true
    };
  }
  if (feature === "mind_plan") {
    const need = String(body.answers?.need || "stress");
    const minutes = Math.max(3, Number(body.answers?.time || 7));
    return {
      title: en ? "Guided nervous-system reset" : "Reset guiado del sistema nervioso",
      session: en ? `Phase 1, 1 min: relax shoulders, jaw and hands.
Phase 2, ${Math.max(1, minutes - 3)} min: inhale 4, exhale 6 while following the flower.
Phase 3, 1 min: choose the next tiny action.
Phase 4, 1 min: close with one sentence: \u201CI only need the next step.\u201D` : `Fase 1, 1 min: suelta hombros, mand\xEDbula y manos.
Fase 2, ${Math.max(1, minutes - 3)} min: inspira 4, exhala 6 siguiendo la flor.
Fase 3, 1 min: elige la siguiente acci\xF3n peque\xF1a.
Fase 4, 1 min: cierra con una frase: \u201Csolo necesito el siguiente paso\u201D.`,
      script: en ? `For ${need}, do not try to fix the whole day. Name what is here, lower the body tension and return to one visible action.` : `Para ${need}, no intentes arreglar el d\xEDa entero. Nombra lo que hay, baja tensi\xF3n del cuerpo y vuelve a una acci\xF3n visible.`,
      sos: en ? "If thoughts speed up, look at one object and exhale twice as long as you inhale." : "Si los pensamientos aceleran, mira un objeto y exhala el doble de lento que inhalas.",
      followUp: en ? "Repeat once later today. If it helped, use it as your default reset for this week." : "Rep\xEDtelo una vez m\xE1s hoy. Si ayud\xF3, \xFAsalo como reset base esta semana.",
      fallback: true
    };
  }
  if (feature === "adapt_workout") {
    return {
      title: en ? "Today, make it repeatable" : "Hoy, hazlo repetible",
      plan: en ? "Keep the first block, reduce one set per exercise if needed, and stop before technique gets messy." : "Mant\xE9n el primer bloque, reduce una serie por ejercicio si hace falta y para antes de que la t\xE9cnica se ensucie.",
      why: en ? "A repeatable workout builds more momentum than a perfect one." : "Un entreno repetible crea m\xE1s continuidad que uno perfecto.",
      fallback: true
    };
  }
  return {
    title: en ? "One useful step" : "Un paso \xFAtil",
    action: en ? "Open today\u2019s workout and complete only the first block. Continue only if it feels easy." : "Abre el entreno de hoy y completa solo el primer bloque. Sigue solo si se siente f\xE1cil.",
    why: en ? "The app should remove friction, not add pressure." : "La app debe quitar fricci\xF3n, no a\xF1adir presi\xF3n.",
    fallback: true
  };
}
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS")
    return { statusCode: 204, headers: corsHeaders, body: "" };
  if (event.httpMethod !== "POST")
    return json({ error: "Method not allowed" }, 405);
  try {
    const body = JSON.parse(event.body || "{}");
    const deviceId = normalizeDeviceId(body.deviceId);
    const plusToken = bearerTokenFromHeaders(event.headers) || String(body.plusToken || "");
    const access = verifyPlusToken(plusToken, deviceId);
    const feature = String(body.feature || "");
    if (!["daily_coach", "adapt_workout", "nutrition_plan", "mind_plan"].includes(feature))
      return json({ error: "Funci\xF3n Plus no disponible" }, 400);
    const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const usageKey = `usage/${access.sub}/${day}`;
    let usageStore = null;
    let usage = { count: 0, updatedAt: "" };
    try {
      usageStore = getStore({ name: "entrenoapp-plus-ai", consistency: "strong" });
      usage = await usageStore.get(usageKey, { type: "json" }) || usage;
    } catch (usageError) {
      console.warn("plus-ai usage tracking skipped", usageError);
    }
    const dailyLimit = Math.max(1, Number(process.env.PLUS_AI_DAILY_LIMIT || 8));
    if (usage.count >= dailyLimit)
      return json({ error: "Has usado las recomendaciones de hoy. Ma\xF1ana tendr\xE1s m\xE1s." }, 429);
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey)
      return json({ error: "La IA de Plus todav\xEDa no est\xE1 conectada" }, 503);
    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash-lite";
    const language = body.context?.language === "en" ? "English" : "Spanish";
    const adapting = feature === "adapt_workout";
    const nutrition = feature === "nutrition_plan";
    const mind = feature === "mind_plan";
    const answers = {
      time: ["short", "medium", "plan"].includes(body.answers?.time) ? body.answers.time : "plan",
      energy: ["low", "normal", "high"].includes(body.answers?.energy) ? body.answers.energy : "normal",
      intent: ["complete", "steady", "progress"].includes(body.answers?.intent) ? body.answers.intent : "complete"
    };
    const forcedMode = answers.time === "short" && answers.energy === "low" ? "express_suave" : answers.time === "short" ? "express" : answers.energy === "low" ? "suave" : "normal";
    const prompt = adapting ? `Eres EntrenoApp Plus, un entrenador amable que reduce decisiones. Escribe en ${language}. El modo seguro ya calculado es ${forcedMode}; no lo cambies. Explica de forma concreta c\xF3mo quedar\xE1 la sesi\xF3n de hoy usando su nombre, ejercicios y duraci\xF3n del contexto. No diagnostiques, no interpretes dolor, no prometas resultados y no a\xF1adas ejercicios nuevos. Devuelve frases breves, sin markdown. Respuestas del usuario: ${compactContext(answers)}. Contexto local anonimizado: ${compactContext(body.context)}` : nutrition ? `Eres EntrenoApp Plus Nutrici\xF3n. Escribe en ${language}. Tu trabajo es crear algo que parezca de una app premium, no una respuesta gen\xE9rica. Crea un plan de nutrici\xF3n de 7 d\xEDas si el usuario pide semana, y si pide d\xEDa o cena, crea igualmente una versi\xF3n ampliada con alternativas. Reglas: no diagnostiques, no trates enfermedades, no prometas resultados, no des calor\xEDas exactas obligatorias, no recomiendes suplementos. Usa comida normal, f\xE1cil de comprar en supermercado, porciones orientativas tipo palma/pu\xF1o/plato. Respeta gustos, alergias y cosas a evitar. Si hay alergias, TCA, embarazo, enfermedad, medicaci\xF3n o restricci\xF3n delicada, a\xF1ade prudencia profesional en rules. Devuelve JSON con: title atractivo; weeklyPlan con 7 l\xEDneas, una por d\xEDa, y cada d\xEDa debe incluir desayuno, comida, cena y snack; shopping con lista agrupada por prote\xEDna, carbohidratos, verduras/fruta y extras; prep con pasos de preparaci\xF3n para que la semana sea f\xE1cil; rules con 4 reglas de adaptaci\xF3n para hambre, entreno fuerte, poco tiempo y restricciones. Evita markdown largo. Respuestas: ${compactContext(body.answers)}. Contexto local anonimizado: ${compactContext(body.context)}` : mind ? `Eres EntrenoApp Plus Mente. Escribe en ${language}. Crea un protocolo guiado de bienestar mental que parezca de una app premium, pr\xE1ctico y profundamente amable. No hagas terapia, no diagnostiques, no prometas curar ansiedad ni sue\xF1o, no uses lenguaje cl\xEDnico. Debe servir para estr\xE9s, foco, \xE1nimo o desconexi\xF3n. Devuelve JSON con: title; session con fases temporizadas y acciones concretas para el tiempo elegido; script con frases internas exactas que el usuario puede repetirse; sos con una versi\xF3n de 60 segundos para cuando se sature; followUp con c\xF3mo repetirlo hoy o durante 7 d\xEDas. Integra respiraci\xF3n con flor, cuerpo, intenci\xF3n y cierre. Nada de frases vagas. Respuestas: ${compactContext(body.answers)}. Contexto local anonimizado: ${compactContext(body.context)}` : `Eres EntrenoApp Plus, un coach de h\xE1bitos y entrenamiento amable. Devuelve una \xFAnica acci\xF3n que pueda hacerse hoy en menos de 20 minutos en ${language}. No diagnostiques, no prescribas dietas ni suplementos y no prometas resultados. Si hay poca informaci\xF3n, recomienda una acci\xF3n suave y concreta. Contexto local anonimizado: ${compactContext(body.context)}`;
    const responseSchema = adapting ? { type: "OBJECT", required: ["title", "plan", "why"], properties: { title: { type: "STRING" }, plan: { type: "STRING" }, why: { type: "STRING" } } } : nutrition ? { type: "OBJECT", required: ["title", "weeklyPlan", "shopping", "prep", "rules"], properties: { title: { type: "STRING" }, weeklyPlan: { type: "STRING" }, shopping: { type: "STRING" }, prep: { type: "STRING" }, rules: { type: "STRING" } } } : mind ? { type: "OBJECT", required: ["title", "session", "script", "sos", "followUp"], properties: { title: { type: "STRING" }, session: { type: "STRING" }, script: { type: "STRING" }, sos: { type: "STRING" }, followUp: { type: "STRING" } } } : { type: "OBJECT", required: ["title", "action", "why"], properties: { title: { type: "STRING" }, action: { type: "STRING" }, why: { type: "STRING" } } };
    let recommendation;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 14e3);
      let response;
      try {
        response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            contents: [{ role: "user", parts: [{ text: prompt }] }],
            generationConfig: { temperature: adapting ? 0.45 : nutrition ? 0.78 : 0.74, maxOutputTokens: nutrition ? 1800 : mind ? 1100 : 320, responseMimeType: "application/json", responseSchema }
          })
        });
      } finally {
        clearTimeout(timeout);
      }
      if (!response.ok)
        throw new Error(`Gemini ${response.status}`);
      const result = await response.json();
      const text = result?.candidates?.[0]?.content?.parts?.[0]?.text || "";
      recommendation = JSON.parse(text);
      if (!recommendation.title)
        throw new Error("Invalid AI response");
      if (adapting && (!recommendation.plan || !recommendation.why))
        throw new Error("Invalid AI response");
      if (nutrition && (!recommendation.weeklyPlan || !recommendation.shopping || !recommendation.prep || !recommendation.rules))
        throw new Error("Invalid AI response");
      if (mind && (!recommendation.session || !recommendation.script || !recommendation.sos || !recommendation.followUp))
        throw new Error("Invalid AI response");
      if (!adapting && !nutrition && !mind && (!recommendation.action || !recommendation.why))
        throw new Error("Invalid AI response");
    } catch (aiError) {
      console.warn("plus-ai fallback", aiError);
      recommendation = fallbackRecommendation(feature, body, language);
    }
    if (adapting) {
      recommendation.mode = forcedMode;
      recommendation.modeLabel = {
        normal: language === "English" ? "Complete" : "Completo",
        express: language === "English" ? "Short" : "Corto",
        suave: language === "English" ? "Gentle" : "Suave",
        express_suave: language === "English" ? "Short + gentle" : "Corto + suave"
      }[forcedMode];
    }
    usage.count += 1;
    usage.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    if (usageStore) {
      try {
        await usageStore.setJSON(usageKey, usage);
      } catch (usageError) {
        console.warn("plus-ai usage save skipped", usageError);
      }
    }
    return json({ recommendation, remaining: Math.max(0, dailyLimit - usage.count) });
  } catch (error) {
    console.error("plus-ai", error);
    const message = error instanceof Error && /expired|invalid access token|access belongs|device/i.test(error.message) ? "Tu acceso Plus ha caducado" : "La recomendaci\xF3n no est\xE1 disponible ahora";
    return json({ error: message }, /caducado/.test(message) ? 401 : 500);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
